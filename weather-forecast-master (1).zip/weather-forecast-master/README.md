#  weather-forecast
## Inspiration
The weather of these days is very weird, we don't know which season will we have tomorrow. This is the reason why we build this, to make sure we are not sick for this weather.  
## What it does
Weather forecast for 1-16 days
## How we built it
By using `HTML`  `CSS` `Javascript` 
## Challenges we ran into
Bad internet connection at flhs
## Accomplishments that we're proud of
Useful, and easy to handle for all ages
## What we learned
Everything
## What's next for weather forecast
Make it into an app, and add more features to it.
## Team Member
- Sophia Xu
- Junyi Wu
- Kay Lin
- Qin Lin
- Junning Quan
